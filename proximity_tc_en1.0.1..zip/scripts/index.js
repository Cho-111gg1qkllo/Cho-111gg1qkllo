import { world, system, BlockComponentTypes } from '@minecraft/server';
let dis = 6;
let ptc = true
let lang = "en"
if (world.getDynamicProperty("lang") !== undefined) {
    lang = world.getDynamicProperty("lang")
}
if (world.getDynamicProperty("proximity") !== undefined) {
    ptc = world.getDynamicProperty("proximity")
}
if (world.getDynamicProperty("distance") !== undefined) {
    dis = world.getDynamicProperty("distance");
}

world.afterEvents.chatSend.subscribe(ev => {
    const { sender, message } = ev;
    if (sender.isOp() == true) {
        if (message === '!help') {
            sender.runCommand(`tellraw "${sender.name}" {"rawtext":[{"text":"--------------------"}]}`);
            if (lang == "ja") {
                sender.runCommand(`tellraw @s {"rawtext":[{"text":"コマンド一覧：\n  !help - ヘルプを表示します\n  !lang - !lang <ja/en> chenge language\n  !dis - !dis <数値> でチャットの届く距離を変更できます\n  !ptc - !ptc <true/false> で近接テキストチャットを有効/無効にできます"}]}`);
            } else {
                sender.runCommand(`tellraw "${sender.name}" {"rawtext":[{"text":"Command list:\n  !help - show help\n  !lang - !lang <ja/en> 言語を変更する\n  !dis - !dis <Number> set max distance for text chat\n  !pvc - !ptc <true/false> enable/disable proximity text chat"}]}`);
            }
            sender.runCommand(`tellraw "${sender.name}" {"rawtext":[{"text":"--------------------"}]}`);
        } else if (message === "!lang en") {
            ev.cancel = true;
            lang = "en"
            world.setDynamicProperty("proximity", "en");
            sender.runCommandAsync(`tellraw @a {"rawtext":[{"text":"<proximity TC>Language set to English"}]}`);
        } else if (message === "!lang ja") {
            ev.cancel = true;
            lang = "ja"
            world.setDynamicProperty("proximity", "ja");
            sender.runCommandAsync(`tellraw @a {"rawtext":[{"text":"<近接TC>言語を日本語に設定しました"}]}`);
        }
        // メッセージを空白で区切りで配列にする
        const msgs = message.split(" ");
        if (msgs[0] === "!dis") {
            world.setDynamicProperty("distance", Number(msgs[1]));
            if (lang === "ja") {
                sender.runCommandAsync(`tellraw @a {"rawtext":[{"text":"テキストチャットの最大距離を${Number(msgs[1])}に変更しました"}]}`);
            } else {
                sender.runCommandAsync(`tellraw @a {"rawtext":[{"text":"Changed max distance for text chat to ${Number(msgs[1])}"}]}`);
            }
        }
    }
});

world.beforeEvents.chatSend.subscribe(ev => {
    const { sender, message } = ev;
    if (sender.isOp() == true) {
        if (message === "!ptc true") {
            ev.cancel = true;
            world.setDynamicProperty("proximity", true);
            if (lang === "ja") {
                sender.runCommandAsync(`tellraw @a {"rawtext":[{"text":"近接TCを有効にしました"}]}`);
            } else {
                sender.runCommandAsync(`tellraw @a {"rawtext":[{"text":"proximity text chat enabled"}]}`);
            }
        } else if (message === "!ptc false") {
            ev.cancel = true;
            world.setDynamicProperty("proximity", false);
            if (lang === "ja") {
                sender.runCommandAsync(`tellraw @a {"rawtext":[{"text":"近接TCを無効にしました"}]}`);
            } else {
                sender.runCommandAsync(`tellraw @a {"rawtext":[{"text":"proximity text chat disabled"}]}`);
            }
        }
    }
    if (world.getDynamicProperty("proximity") !== undefined) {
        ptc = world.getDynamicProperty("proximity")
    }
    if (world.getDynamicProperty("distance") !== undefined) {
        dis = world.getDynamicProperty("distance");
    }
    if (ptc === true) {
        if (!message.includes(`!`)) {
            ev.cancel = true;
            sender.runCommandAsync(`tellraw @a[r=${dis}] {"rawtext":[{"text":"<${sender.name}> ${message}"}]}`);
        }
    }
});